package controller;

import java.util.Scanner;

import model.Collection;

public class Avvio {
	public static void main(String[] args) {
		Collection collezione = new Collection();
		Scanner input = new Scanner(System.in);
		int scelta;
		
		do {
			System.out.println("\n1: ArrayList\n2: HashMap\n3: HashMapDue\n4: HashMapDueBis\n5: Coda FIFO\n6: Coda LIFO\n7: Esci\n");
			System.out.println("Scegli: ");
			scelta = Integer.parseInt(input.nextLine());
			switch(scelta) {
			case 1:
				collezione.insieme();
				break;
			case 2:
				collezione.hashMapDue();
				break;
			case 3:
				collezione.hashMapDueBis();
				break;
			case 4:
				collezione.HashMapTre();
				break;
			case 5:
				collezione.codaFIFO();
				break;
			case 6:
				collezione.codaLIFO();
				break;
			case 7:
				System.out.println("Sei uscito dal men�");
				break;
			default:
				System.out.println("Hai inserito un numero errato!");
			}
			
		}while(scelta != 7);
		
	}
}
