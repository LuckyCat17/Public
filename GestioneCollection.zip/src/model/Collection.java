package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.TreeSet;

public class Collection {
	
	public void insieme() {
		ArrayList<Persona> persone = new ArrayList<>();
		persone.add(new Persona(1, "Antonio", "Napolitano", 21, "Maschio", "NTNNPL"));
		persone.add(new Persona(1, "Antonio", "Napolitano", 21, "Maschio", "NTNNPL"));
		persone.add(new Persona(2, "Salvatore", "Tarantino", 21, "Maschio", "SLVTR"));
		persone.add(new Persona(3, "Pietro", "Ruggiero", 21, "Maschio", "PTRRG"));
		persone.add(new Persona(1, "Antonio", "Napolitano", 21, "Maschio", "NTNNPL"));
		persone.add(new Persona(4, "Antonella", "Manganelli", 25, "Femmina", "NTNMG"));
		
		System.out.println("---- Elenco persone in ordine Naturale ----");
		for(int i=0; i<persone.size(); i++) {
			System.out.println(persone.get(i).toString());
		}
		
		System.out.println("\n---- Elenco persone ordinato per Nome ----");
		persone.sort((p1,p2) -> (p1.getNome().compareTo(p2.getNome())));
		for(Persona persona: persone) {
			System.out.println(persona.toString());
		}
		
		System.out.println("\n--- Elenco persone ordinato per Et� ----");
		persone.sort((p1,p2) -> (p1.getEta()-p2.getEta()));
		for(Persona persona: persone) {
			System.out.println(persona.toString());
		}
		
		System.out.println("\n---- Elenco persone ordinato per Nome e Cognome ----");
		Collections.sort(persone);
		for(Persona persona: persone) {
			System.out.println(persona.toString());
		}
		
		System.out.println("\n---- Elenco persone senza duplicati ----");
		HashSet<Persona> personeNonOrdinate = new HashSet<Persona>(persone);
		for(Persona persona: personeNonOrdinate) {
			System.out.println(persona.toString());
		}
			
		System.out.println("\n---- Elenco persone ordinato senza duplicati ----");
		TreeSet<Persona> personeOrdinate = new TreeSet<Persona>(persone);
		for(Persona persona: personeOrdinate) {
			System.out.println(persona.toString());
		}
		
		/*SET con UpCasting
		Set<Persona> personeSetNonOrdinato=new HashSet<Persona>(persone);
		System.out.println("\n---- Elenco persone senza duplicati ----");
		for(Persona persona: personeSetNonOrdinato) {
			System.out.println(persona.toString());
		}
		
		Set<Persona> personeSetOrdinato = new TreeSet<Persona>(persone);
		System.out.println("\n---- Elenco persone ordianto senza duplicati ----");
		for(Persona persona: personeSetOrdinato) {
			System.out.println(persona.toString());
		} */

	}
	
	public void hashMapDue() {
		HashMap<String,String> prodotti = new HashMap<String,String>();
		
		Scanner input = new Scanner(System.in);
		String chiave;
		
		prodotti.put("comp1", "Computer Axus");
		prodotti.put("comp2", "Computer HP");
		prodotti.put("stmp1", "Stampante Laser");
		prodotti.put("mou1","Mouse Axus");
		prodotti.put("mou2","Mouse HP");
		
		try {
			System.out.println("\n\nInserire la chiave: ");
			chiave = input.nextLine();
			System.out.println(prodotti.get(chiave));
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public void hashMapDueBis() {
		HashMap<Integer,String> prodotti = new HashMap<Integer,String>();
		
		Scanner input = new Scanner(System.in);
		Integer chiave;
		
		prodotti.put(1, "Computer Axus");
		prodotti.put(2, "Computer HP");
		prodotti.put(3, "Stampante Laser");
		prodotti.put(4,"Mouse Axus");
		prodotti.put(5,"Mouse HP");
		
		try {
			System.out.println("\n\nInserire la chiave: ");
			chiave = Integer.parseInt(input.nextLine());
			System.out.println(prodotti.get(chiave));
		}catch (Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void HashMapTre() {

		HashMap<String,Persona> persone=new HashMap<String,Persona>();
		Scanner input=new Scanner(System.in);
		String chiave;
		persone.put("uno",new Persona(1, "Antonio", "Napolitano", 21, "Maschio", "NTNNPL"));
		persone.put("due",new Persona(2, "Salvatore", "Tarantino", 21, "Maschio", "SLVTR"));
		persone.put("tre",new Persona(3, "Pietro", "Ruggiero", 21, "Maschio", "PTRRG"));
		persone.put("quattro",new Persona(4, "Antonella", "Manganelli", 25, "Femmina", "NTNMG"));

		System.out.println("\n----- Elenco delle chiavi di Persone -----");
		for(String key: persone.keySet()) {
			System.out.println(key);
			
		}
		
		System.out.println("\n----- Elenco delle chiavi di Persone con get -----");
		for(String key: persone.keySet()) {
				System.out.println(persone.get(key).toString());
		}
		
		System.out.println("\n----- Elenco delle Persone con values-----");
		for(Persona persona: persone.values()) {
			System.out.println(persona.toString());
		}
		
		System.out.println("\n---- Persone Ordinate ----");
		TreeSet<Persona> personeOrdinate = new TreeSet<Persona>(persone.values());
		for(Persona persona: personeOrdinate) {
			System.out.println(persona);
		}
		
		TreeSet<Persona> ts=new TreeSet<>((personaA, personaB) -> (personaA.getNome()+personaA.getCognome()).compareTo((personaB.getNome()+personaB.getCognome())));
		ts.add(new Persona(1,"Mario","Rossi",20, "maschio", "mr"));
		ts.add(new Persona(5,"Aldo","Verdi",35,"maschio", "av"));
		ts.add(new Persona(4,"Roberta","Rossi",25,"femmina","rr"));
		ts.add(new Persona(5,"Aldo","Verdi",35,"maschio", "av"));
		ts.add(new Persona(2, "Paola","Rossi",30, "femmina", "pr"));
		ts.add(new Persona(3, "Ugo","Verdi",40, "maschio", "uv"));
		ts.add(new Persona(4,"Roberta","Rossi",25,"femmina","rr"));
		ts.add(new Persona(4,"Roberta","Rossi",25,"femmina","rr"));
		ts.add(new Persona(5,"Aldo","Verdi",35,"maschio", "av"));
		System.out.println("\n----- Persone ordinate Lambda-----");
		for(Persona persona: ts) {
			System.out.println(persona.toString());
		}
		
		System.out.println("\nInserire chiave persona: ");
		chiave = input.nextLine();
		System.out.println(persone.get(chiave).toString());
	}
	
	public void codaFIFO() {
		
		Queue<Integer> coda=new LinkedList<>();
		
		for(int i=0; i<10; i++) {
			coda.add((int)(Math.random()*10+1));
		}
		
		System.out.println("\n----- Iterator -----");
		Iterator iterator=coda.iterator();
		System.out.println("Elementi nella coda:"+coda.size());
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}		
		System.out.println("Elementi nella coda: "+coda.size());
		
		System.out.println("\n----- poll -----");
		System.out.println("Elementi nella coda: "+coda.size());
		for(int i=0; i<10; i++) {
			System.out.println(coda.poll());
		}	
		System.out.println("Elementi nella coda: "+coda.size());
	}
	
	public void codaLIFO() {
		Stack<Integer> coda=new Stack<Integer>();
		for(int i=0; i<10; i++) {
			coda.push((int)(Math.random()*10+1));
		}
		
		System.out.println("\nValori prima della stampa:"+coda.size());
		System.out.println("---- Stampa con get ----");
		for(int i=0; i<coda.size(); i++) {
			System.out.println(coda.get(i));
		}
		System.out.println("\nValori dopo la stampa con get:"+coda.size());
		
		System.out.println("---- Stampa con pop ----");
		for(int i=0; i<10; i++) {
			System.out.println(coda.pop());
		}
		System.out.println("\nValori dopo la stampa con pop:"+coda.size());
	}
}