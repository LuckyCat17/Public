package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Persona implements Comparable<Persona>{

		// attributi
		private int id;
		private String nome;
		private String cognome;
		private int eta;
		private String sesso;
		private String codiceFiscale;

		//metodi setter - getter
		public void setId(int id) {
			this.id = id;
		}
					
		public int getId() {
			return id;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public String getNome() {
			return nome;
		}
		
		public void setCognome(String cognome) {
			this.cognome = cognome;
		}

		public String getCognome() {
			return cognome;
		}
		
		public void setEta(int eta) {
			this.eta = eta;
		}
					
		public int getEta() {
			return eta;
		}
		
		public void setSesso(String sesso) {
			this.sesso = sesso;
		}

		public String getSesso() {
			return sesso;
		}
			
		public void setCodiceFiscale(String codiceFiscale) {
			this.codiceFiscale = codiceFiscale;
		}
				
		public String getCodiceFiscale() {
			return codiceFiscale;
		}
		
		//costruttori
		public Persona() {}
		
		public Persona(int id, String nome,String cognome, int eta, String sesso, String codiceFiscale) {
			this.id = id;
			this.nome = nome;
			this.cognome = cognome;
			this.eta = eta;
			this.sesso = sesso;
			this.codiceFiscale = codiceFiscale;
		}
		
		@Override
		public String toString() {
			return id+","+nome+","+cognome+","+eta+","+sesso+","+codiceFiscale;
		}

		public int compareTo(Persona obj) {
			String nominativoUno,nominativoDue;
			nominativoUno=this.nome+this.cognome;
			nominativoDue=obj.nome+obj.cognome;
			return nominativoUno.compareTo(nominativoDue);
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((codiceFiscale == null) ? 0 : codiceFiscale.hashCode());
			result = prime * result + ((cognome == null) ? 0 : cognome.hashCode());
			result = prime * result + eta;
			result = prime * result + id;
			result = prime * result + ((nome == null) ? 0 : nome.hashCode());
			result = prime * result + ((sesso == null) ? 0 : sesso.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Persona other = (Persona) obj;
			if (codiceFiscale == null) {
				if (other.codiceFiscale != null)
					return false;
			} else if (!codiceFiscale.equals(other.codiceFiscale))
				return false;
			if (cognome == null) {
				if (other.cognome != null)
					return false;
			} else if (!cognome.equals(other.cognome))
				return false;
			if (eta != other.eta)
				return false;
			if (id != other.id)
				return false;
			if (nome == null) {
				if (other.nome != null)
					return false;
			} else if (!nome.equals(other.nome))
				return false;
			if (sesso == null) {
				if (other.sesso != null)
					return false;
			} else if (!sesso.equals(other.sesso))
				return false;
			return true;
		}
		
}